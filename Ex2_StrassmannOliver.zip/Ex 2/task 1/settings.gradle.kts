
rootProject.name = "Ex2"

