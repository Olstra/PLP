
rootProject.name = "Lottery"

