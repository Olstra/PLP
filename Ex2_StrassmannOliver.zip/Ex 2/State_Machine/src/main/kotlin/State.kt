/**
 * Class representing a state
 * */
class State(var stateTxt: String) {

    var transitions: ArrayList<Transition>? = null // default value

    // add a transition to our transitions list
    fun addTransition(transition: Transition){
        this.transitions?.add(transition)
    }
}