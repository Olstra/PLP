/**
 * This class reads a text file and stores its contents
 * @param filePath: path where the file is stored
 * */
class FileReader(var filePath: String) {






}