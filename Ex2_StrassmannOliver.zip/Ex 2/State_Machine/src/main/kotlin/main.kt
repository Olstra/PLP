fun main(args: Array<String>) {
    var stateT = State("myName")
    var x = Transition("lala", stateT)

    // test states
    var s1 = State("s1")
    var s2 = State("s2")
    var s3 = State("s3")
    var s4 = State("s4")

    // transitions test
    var t1 = Transition("aaa", s1)
    var t2 = Transition("aaa", s2)
    var t3 = Transition("aaa", s3)
    var t4 = Transition("aaa", s4)

    s1.addTransition(t1)
    s1.addTransition(t2)
    s2.addTransition(t3)

    var sm = StateMachine()
    sm.initSM(s1)
    sm.addState(s2)

    //var userInput = "test"
    //var userInput = readLine()
    print(sm.getCurrentState()?.stateTxt)
    sm.changeState("aaa")
    print(sm.getCurrentState()?.stateTxt)




}