/**
 * Requirements:
 * has an initial state
 * has ending states
 * it is possible to go from a state to another according to the transitions
 * */
class StateMachine() {

    // init all members to null
    // concrete values will be assigned when "initialize" method is called
    private var allStates: ArrayList<State>? = null
    private var currentState: State? = null
    private var startState: State? = null

    fun initSM(startState: State){
        this.startState = startState
        this.currentState = startState
    }

    fun getCurrentState(): State? { return this.currentState }

    // add new state if not already in arraylist
    fun addState(state: State){
        if(allStates?.contains(state) == false){
            this.allStates?.add(state)
        }
        else{ println("ERROR: state already saved in state machine") }
    }

    // update the current state of the SM
    fun changeState(transitionWord: String){
        for(t in currentState?.transitions!!){
            if(t.transitionKeyword == transitionWord){
                currentState = t.toState
                return
            }
        }
        println("ERROR: transition not found")
    }
}