class Transition(var transitionKeyword: String, var toState: State) {

}