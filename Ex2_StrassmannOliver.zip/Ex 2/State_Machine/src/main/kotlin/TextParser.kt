class TextParser(var inputText: String) {
    var transitions = 0
    var states = 0 // TODO which data type for transitions, states



}